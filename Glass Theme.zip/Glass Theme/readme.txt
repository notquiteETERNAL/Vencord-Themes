Vencord Themes | Glass Theme

Put Glass.css in your themes folder.
(Settings > Vencord Settings > Themes > Open Themes Folder)

Not showing? Click the "Load missing Themes" button.

Go to Vencord settings and enable "Enable window transparency", then restart Discord.
(Settings > Vencord Settings > Vencord > Enable window transparency)

If "Background Material" is set to anything other than "None" the theme wont work.
(Settings > Vencord Settings > Vencord > Background Material)

Enable the Glass Theme in the Themes page.
(Settings > Vencord Settings > Themes)

-

If the theme still doesn't work or load, redo the steps above, and if that still fails please submit an Issue request on the GitHub repo.