Vencord Themes | Zero Two Theme

Theme
Put Zero Two.css in your themes folder.
(Settings > Vencord Settings > Themes > Open Themes Folder)

Not showing? Click the "Load missing Themes" button.

Enable the Zero Two Theme in the Themes page.
(Settings > Vencord Settings > Themes)

Overlay
Put Zero Two Overlay.css AND ZeroTwoCorner.png in your themes folder.
(Settings > Vencord Settings > Themes > Open Themes Folder)

Not showing? Click the "Load missing Themes" button.

Enable the Zero Two Overlay in the Themes page.
(Settings > Vencord Settings > Themes)

-

If the theme still doesn't work or load, redo the steps above, and if that still fails please submit an Issue request on the GitHub repo.

-

Note: This theme is basically finished. This means that there are only one, (or very few), things that is going to be edited in the future.